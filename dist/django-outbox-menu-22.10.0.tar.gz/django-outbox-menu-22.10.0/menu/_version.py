"""
Provides menu version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update menu` to change this file.

from incremental import Version

__version__ = Version("menu", 22, 10, 0)
__all__ = ["__version__"]
